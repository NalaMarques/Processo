# Diferenças dos Planos — Top Streaming

Este repositório contém uma página HTML criada para apresentar, de forma clara e didática, as diferenças entre os planos oferecidos pela Top Streaming.

## 📄 Arquivos incluídos
- index.html  
- LICENSE  

## 🚀 Como usar
Abra o arquivo `index.html` no navegador.

## ✨ Autor
Alan Marques / Top Streaming
